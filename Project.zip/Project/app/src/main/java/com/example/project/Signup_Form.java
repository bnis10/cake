package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Signup_Form extends AppCompatActivity implements View.OnClickListener {
    private EditText fullname, email, password, confirmpassword, username;
    private Button register;
    private Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup__form);
        fullname = findViewById(R.id.fullname);
        email = findViewById(R.id.email);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        confirmpassword = findViewById(R.id.confirmpassword);
        register = findViewById(R.id.register);
        register.setOnClickListener(this);

    }



    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    public void onClick(View v) {
        String inputpassword = password.getText().toString();
        String inputconfirmpassword = confirmpassword.getText().toString();
        String user = username.getText().toString();
        String txtemail = email.getText().toString();
        String txtfullname = fullname.getText().toString();
        if (inputpassword.equals("") && inputconfirmpassword.equals("") && user.equals("")
                && txtemail.equals("") && txtfullname.equals("")) {
        } else if (inputpassword.equals(inputconfirmpassword)) {
            Intent init = new Intent(this, Login_Form.class);
            startActivity(init);
        }
    }
}

