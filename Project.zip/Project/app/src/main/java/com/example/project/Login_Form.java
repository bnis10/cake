package com.example.project;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Login_Form extends AppCompatActivity implements View.OnClickListener {
    private EditText txtemail, txtpassword;
    private Button btnlogin, btnregister;
    private Dialog originalDialog;
    private AlertDialog.Builder alertDialogBuilder;
    private Toolbar toolbar;
    private ImageView imgPhoto;
    private Uri picUri;
    private String currentImagePath;
    private Bitmap bitmap;
    private String type = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login__form);
        txtemail = findViewById(R.id.txtemail);
        txtpassword = findViewById(R.id.txtpassword);
        btnlogin = findViewById(R.id.login);
        btnregister = findViewById(R.id.register);
        btnlogin.setOnClickListener(this);
        btnregister.setOnClickListener(this);

    }

    public void onClick(View v) {
        if (v.getId() == R.id.login) {
            String inputEmail = txtemail.getText().toString();
            String inputPassword = txtpassword.getText().toString();
            String defaultUser = "Binish";
            String defaultPassword = "baka";

            if (inputEmail.equals(defaultUser) && inputPassword.equals(defaultPassword)) {
                Intent goToMainActivity = new Intent(this, MainActivity.class);
                startActivity(goToMainActivity);
            }

        } else if (v.getId() == R.id.register) {
            Intent goToSignUpPage = new Intent(this, Signup_Form.class);
            startActivity(goToSignUpPage);
        }
    }

}


